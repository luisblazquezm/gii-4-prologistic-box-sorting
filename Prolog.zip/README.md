# prologistic-box-sorting
Trabajo de la asignatura "Fundamentos de Sistemas Inteligentes" para el desarrollo de una solución utilizando el lenguaje PROLOG para el ordenamiento y retirada ordenada de una serie de cajas apiladas en cinco montones en un almacén
